package pacman;

/**
 * Enum to represent modes of game, with values CHASE, SCATTER, FRIGHTENED.
 */
public enum GameMode {
    CHASE, SCATTER, FRIGHTENED;
}
